﻿namespace RMTOFG
{
    partial class frmFG
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstFG = new System.Windows.Forms.ListBox();
            this.btnAddFG = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lstFG
            // 
            this.lstFG.FormattingEnabled = true;
            this.lstFG.Location = new System.Drawing.Point(47, 56);
            this.lstFG.Name = "lstFG";
            this.lstFG.Size = new System.Drawing.Size(307, 121);
            this.lstFG.TabIndex = 0;
            // 
            // btnAddFG
            // 
            this.btnAddFG.Location = new System.Drawing.Point(160, 225);
            this.btnAddFG.Name = "btnAddFG";
            this.btnAddFG.Size = new System.Drawing.Size(75, 23);
            this.btnAddFG.TabIndex = 1;
            this.btnAddFG.Text = "Add";
            this.btnAddFG.UseVisualStyleBackColor = true;
            this.btnAddFG.Click += new System.EventHandler(this.BtnAddFG_Click);
            // 
            // FG
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(427, 317);
            this.Controls.Add(this.btnAddFG);
            this.Controls.Add(this.lstFG);
            this.Name = "FG";
            this.Text = "Finished Goods";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lstFG;
        private System.Windows.Forms.Button btnAddFG;
    }
}

