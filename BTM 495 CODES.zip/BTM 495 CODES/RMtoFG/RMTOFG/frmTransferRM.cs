﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RMTOFG
{
    public partial class frmTransferRM : Form
    {
        private FinishedGood finishedGood;

        public FinishedGood GetNew()
        {
            ShowDialog();
            return finishedGood;
        }
        public frmTransferRM()
        {
            InitializeComponent();
        }

        private void BtnTransfer_Click(object sender, EventArgs e)
        {
          
           string RM = txtRM.Text;
            string FG = txtFG.Text;
            int Quantity = int.Parse(txtRMQ.Text);

            int transfered = Quantity / 2;

            MessageBox.Show(transfered + " new products have been added to " + FG);
        }
    }
}
