﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Events
{
    class Event
    {

        private int numberOfAttendees;
        private string name;
        private string address;
        private string type;

        public Event() { }

        public Event(string n, string a, string t, int na)
        {

            Name = n;
            Address = a;
            Type = t;
            NOA = na;

        }


        public string Type
        {
            get { return type; }
            set { type = value; }
        }

        public int NOA
        {
            get
            {
                return numberOfAttendees;
            }
            set
            {
                numberOfAttendees = value;
            }
        }

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        public string Address
        {
            get { return address; }
            set { address = value; }
        }


        public string ShowInfo()
        {

            return "Name: " + Name + " Address: " + Address + " Type: " +
                    Type + " NOfAttendees: " + NOA ;
        }

    }
}
