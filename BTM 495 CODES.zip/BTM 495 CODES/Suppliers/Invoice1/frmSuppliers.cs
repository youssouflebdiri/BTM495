﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Suppliers
{
    public partial class frmSuppliers : Form
    {
        List<Supplier> supList = new List<Supplier>();

        public frmSuppliers()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            

            Supplier s;

            s = new Supplier(int.Parse(txtID.Text), txtSupplierName.Text, txtAddress.Text, txtCity.Text, txtPro.Text, txtPC.Text);

            supList.Add(s);

            lstSuppliers.Items.Add(s.Name);

            txtAddress.Text = "";
            txtCity.Text = "";
            txtID.Text = "";
            txtSupplierName.Text = "";
            txtPro.Text = "";
            txtPC.Text = "";



        }

        private void lstSuppliers_DoubleClick(object sender, EventArgs e)
        {

            int ind;

            ind = lstSuppliers.SelectedIndex;

            MessageBox.Show(supList[ind].ShowInfo());


        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            if (lstSuppliers.Items.Count >= 1)
            {
                               lstSuppliers.Items.Remove(lstSuppliers.SelectedItem);

            }
            else
            {
                System.Windows.Forms.MessageBox.Show("No items found");
            }
        }
    }
}
