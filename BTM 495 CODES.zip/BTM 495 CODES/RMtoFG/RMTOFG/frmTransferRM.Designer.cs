﻿namespace RMTOFG
{
    partial class frmTransferRM
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtRMQ = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtFG = new System.Windows.Forms.TextBox();
            this.txtRM = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.btnTransfer = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtRMQ
            // 
            this.txtRMQ.Location = new System.Drawing.Point(173, 82);
            this.txtRMQ.Name = "txtRMQ";
            this.txtRMQ.Size = new System.Drawing.Size(84, 20);
            this.txtRMQ.TabIndex = 16;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(44, 85);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(111, 13);
            this.label4.TabIndex = 15;
            this.label4.Text = "Raw Material Quantity";
            // 
            // txtFG
            // 
            this.txtFG.Location = new System.Drawing.Point(173, 122);
            this.txtFG.Name = "txtFG";
            this.txtFG.Size = new System.Drawing.Size(136, 20);
            this.txtFG.TabIndex = 14;
            // 
            // txtRM
            // 
            this.txtRM.Location = new System.Drawing.Point(173, 40);
            this.txtRM.Name = "txtRM";
            this.txtRM.Size = new System.Drawing.Size(137, 20);
            this.txtRM.TabIndex = 13;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(44, 125);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(80, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Finished Goods";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(44, 44);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Raw Material";
            // 
            // btnTransfer
            // 
            this.btnTransfer.Location = new System.Drawing.Point(146, 210);
            this.btnTransfer.Name = "btnTransfer";
            this.btnTransfer.Size = new System.Drawing.Size(75, 23);
            this.btnTransfer.TabIndex = 17;
            this.btnTransfer.Text = "Transfer";
            this.btnTransfer.UseVisualStyleBackColor = true;
            this.btnTransfer.Click += new System.EventHandler(this.BtnTransfer_Click);
            // 
            // frmTransferRM
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(443, 303);
            this.Controls.Add(this.btnTransfer);
            this.Controls.Add(this.txtRMQ);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtFG);
            this.Controls.Add(this.txtRM);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Name = "frmTransferRM";
            this.Text = "frmTransferRM";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtRMQ;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtFG;
        private System.Windows.Forms.TextBox txtRM;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnTransfer;
    }
}