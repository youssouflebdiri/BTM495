﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Events
{
    public partial class frmEvents : Form
    {
        List<Event> eventList = new List<Event>();
        public frmEvents()
        {
            InitializeComponent();
        }

        private void Label4_Click(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            Event ev;

            ev = new Event(txtName.Text, txtAddress.Text, txtType.Text, int.Parse(txtNOA.Text));
          
            eventList.Add(ev);

            lstEvents.Items.Add(ev.Name);

            txtAddress.Text = "";
            txtType.Text = "";
            txtNOA.Text = "";
            txtName.Text = "";

        }

        private void LstEvents_SelectedIndexChanged(object sender, EventArgs e)
        {
            int ind;

            ind = lstEvents.SelectedIndex;

            MessageBox.Show(eventList[ind].ShowInfo());
        }
    }
}
