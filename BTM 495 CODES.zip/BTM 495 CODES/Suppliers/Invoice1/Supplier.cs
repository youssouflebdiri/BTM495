﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Suppliers
{
    class Supplier
    {

        private int id;
        private string name;
        private string address;
        private string city;
        private string province;
        private string postalcode;


        public Supplier() { }

        public Supplier(int i, string n, string a, string c, string p, string pc) {

            ID = i;
            Name = n;
            Address = a;
            City = c;
            Province = p;
            PostalCode = pc;
        
        }

        public int ID {
            get {
                return id;
            }
            set {
                id = value;
            }
        }

        public string Name
            {
                get { return name; }
                set { name = value; }
            }

        public string Address
        {
            get { return address; }
            set { address = value; }
        }

        public string City
        {
            get { return city; }
            set { city = value; }

        }

        public string Province
        {
            get { return province; }
            set { province = value; }
        }

        public string PostalCode
        {
            get { return postalcode; }
            set { postalcode = value; }
        }

        public string ShowInfo(){
        
        return "ID: "+ ID + " Name: " + Name + " Address: " + Address + " City: " + 
                City + " Province: " + Province + " PostalCode: " + PostalCode;
        }


    }
}
